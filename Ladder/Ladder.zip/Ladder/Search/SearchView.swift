//
//  SearchView.swift
//  Ladder
//
//  Created by Toranosuke Ugajin on 11/16/24.
//

import SwiftUI

struct SearchView: View {
    var body: some View {
        Text("Serach")
    }
}

#Preview {
    SearchView()
}
