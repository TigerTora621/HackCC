//
//  NotificationView.swift
//  Ladder
//
//  Created by Toranosuke Ugajin on 11/16/24.
//

import SwiftUI

struct NotificationView: View {
    var body: some View {
        Text("Notification View comes here")
    }
}

#Preview {
    NotificationView()
}
